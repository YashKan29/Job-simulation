import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface TaskAnalytics {
  sceneId: string;
  sceneName: string;
  taskName: string;
  submittedAt: string;
  score: number; // 0-100
  attempts: number;
  timeSpent: number; // in seconds
  feedback: string;
  strengths: string[];
  improvements: string[];
  codeQuality?: number;
  technicalSkills: string[];
  softSkills: string[];
}

export interface PortfolioData {
  userName: string;
  userEmail: string;
  githubUsername?: string;
  startDate: string;
  completionDate?: string;
  overallScore: number;
  totalTasksCompleted: number;
  totalTimeSpent: number;
  taskAnalytics: TaskAnalytics[];
  skillsAcquired: {
    technical: Record<string, number>; // skill -> proficiency (0-100)
    soft: Record<string, number>;
  };
  achievements: Achievement[];
  projectLinks: string[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  earnedAt: string;
  icon: string;
}

interface AnalyticsStore {
  portfolio: PortfolioData | null;
  currentTaskStartTime: number | null;

  initializePortfolio: (userName: string, userEmail: string) => void;
  startTask: () => void;
  recordTaskCompletion: (analytics: TaskAnalytics) => void;
  addAchievement: (achievement: Achievement) => void;
  updateGithubUsername: (username: string) => void;
  addProjectLink: (link: string) => void;
  getPortfolioData: () => PortfolioData | null;
  calculateOverallScore: () => number;
  generatePortfolio: () => Promise<string>; // Returns HTML
}

export const useAnalyticsStore = create<AnalyticsStore>()(
  persist(
    (set, get) => ({
      portfolio: null,
      currentTaskStartTime: null,

      initializePortfolio: (userName: string, userEmail: string) => {
        set({
          portfolio: {
            userName,
            userEmail,
            startDate: new Date().toISOString(),
            overallScore: 0,
            totalTasksCompleted: 0,
            totalTimeSpent: 0,
            taskAnalytics: [],
            skillsAcquired: {
              technical: {},
              soft: {}
            },
            achievements: [],
            projectLinks: []
          }
        });
      },

      startTask: () => {
        set({ currentTaskStartTime: Date.now() });
      },

      recordTaskCompletion: (analytics: TaskAnalytics) => {
        const state = get();
        if (!state.portfolio) return;

        const timeSpent = state.currentTaskStartTime
          ? Math.floor((Date.now() - state.currentTaskStartTime) / 1000)
          : 0;

        const updatedAnalytics = {
          ...analytics,
          timeSpent
        };

        // Update technical skills
        const technicalSkills = { ...state.portfolio.skillsAcquired.technical };
        analytics.technicalSkills.forEach(skill => {
          technicalSkills[skill] = Math.min(100, (technicalSkills[skill] || 0) + 10);
        });

        // Update soft skills
        const softSkills = { ...state.portfolio.skillsAcquired.soft };
        analytics.softSkills.forEach(skill => {
          softSkills[skill] = Math.min(100, (softSkills[skill] || 0) + 10);
        });

        set({
          portfolio: {
            ...state.portfolio,
            taskAnalytics: [...state.portfolio.taskAnalytics, updatedAnalytics],
            totalTasksCompleted: state.portfolio.totalTasksCompleted + 1,
            totalTimeSpent: state.portfolio.totalTimeSpent + timeSpent,
            skillsAcquired: {
              technical: technicalSkills,
              soft: softSkills
            }
          },
          currentTaskStartTime: null
        });
      },

      addAchievement: (achievement: Achievement) => {
        const state = get();
        if (!state.portfolio) return;

        set({
          portfolio: {
            ...state.portfolio,
            achievements: [...state.portfolio.achievements, achievement]
          }
        });
      },

      updateGithubUsername: (username: string) => {
        const state = get();
        if (!state.portfolio) return;

        set({
          portfolio: {
            ...state.portfolio,
            githubUsername: username
          }
        });
      },

      addProjectLink: (link: string) => {
        const state = get();
        if (!state.portfolio) return;

        if (!state.portfolio.projectLinks.includes(link)) {
          set({
            portfolio: {
              ...state.portfolio,
              projectLinks: [...state.portfolio.projectLinks, link]
            }
          });
        }
      },

      getPortfolioData: () => {
        return get().portfolio;
      },

      calculateOverallScore: () => {
        const state = get();
        if (!state.portfolio || state.portfolio.taskAnalytics.length === 0) return 0;

        const totalScore = state.portfolio.taskAnalytics.reduce(
          (sum: number, task: TaskAnalytics) => sum + task.score,
          0
        );
        return Math.round(totalScore / state.portfolio.taskAnalytics.length);
      },

      generatePortfolio: async () => {
        const state = get();
        if (!state.portfolio) return '';

        const overallScore = get().calculateOverallScore();

        set({
          portfolio: {
            ...state.portfolio,
            completionDate: new Date().toISOString(),
            overallScore
          }
        });

        return generatePortfolioHTML(state.portfolio);
      }
    }),
    {
      name: 'velsy-portfolio-storage'
    }
  )
);

// Helper function to generate HTML
function generatePortfolioHTML(portfolio: PortfolioData): string {
  const overallScore = portfolio.overallScore;
  const completionDate = portfolio.completionDate
    ? new Date(portfolio.completionDate).toLocaleDateString()
    : 'In Progress';

  const skillsHTML = Object.entries(portfolio.skillsAcquired.technical)
    .map(([skill, level]) => `
      <div class="skill-item">
          <div class="skill-name">
              <span>${skill}</span>
              <span>${level}%</span>
          </div>
          <div class="skill-bar">
              <div class="skill-progress" style="width: ${level}%"></div>
          </div>
      </div>
    `).join('');

  const softSkillsHTML = Object.entries(portfolio.skillsAcquired.soft)
    .map(([skill, level]) => `
      <div class="skill-item">
          <div class="skill-name">
              <span>${skill}</span>
              <span>${level}%</span>
          </div>
          <div class="skill-bar">
              <div class="skill-progress" style="width: ${level}%"></div>
          </div>
      </div>
    `).join('');

  const achievementsHTML = portfolio.achievements.length > 0 ? `
    <div class="section">
        <h2 class="section-title">🎖️ Achievements Unlocked</h2>
        <div class="achievement-grid">
            ${portfolio.achievements.map((achievement: Achievement) => `
                <div class="achievement-card">
                    <div class="achievement-icon">${achievement.icon}</div>
                    <div class="achievement-title">${achievement.title}</div>
                    <div class="achievement-desc">${achievement.description}</div>
                </div>
            `).join('')}
        </div>
    </div>
  ` : '';

  const tasksHTML = portfolio.taskAnalytics.map((task: TaskAnalytics) => `
    <div class="task-item">
        <div class="task-header">
            <div>
                <div class="task-title">${task.sceneName}</div>
                <div style="color: #666; font-size: 0.95em;">${task.taskName}</div>
            </div>
            <div class="task-score ${getScoreClass(task.score)}">
                ${task.score}%
            </div>
        </div>

        <div class="task-details">
            <div class="detail-item">
                <div class="detail-label">Attempts</div>
                <div class="detail-value">${task.attempts}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Time Spent</div>
                <div class="detail-value">${formatTimeHTML(task.timeSpent)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">Submitted</div>
                <div class="detail-value">${new Date(task.submittedAt).toLocaleDateString()}</div>
            </div>
        </div>

        ${task.strengths.length > 0 ? `
        <div class="strengths">
            <div class="strengths-title">Key Strengths Demonstrated:</div>
            <ul>
                ${task.strengths.map(strength => `<li>${strength}</li>`).join('')}
            </ul>
        </div>
        ` : ''}

        <div class="tech-stack">
            ${task.technicalSkills.map(skill =>
                `<span class="tech-badge">${skill}</span>`
            ).join('')}
        </div>
    </div>
  `).join('');

  const projectLinksHTML = portfolio.projectLinks.length > 0 ? `
    <div class="section">
        <h2 class="section-title">🔗 Project Links</h2>
        <div style="display: flex; flex-direction: column; gap: 15px;">
            ${portfolio.projectLinks.map(link => `
                <a href="${link}" target="_blank" style="
                    padding: 15px 20px;
                    background: #f8f9fa;
                    border-left: 4px solid #667eea;
                    border-radius: 8px;
                    text-decoration: none;
                    color: #667eea;
                    font-weight: 600;
                    display: block;
                ">${link}</a>
            `).join('')}
        </div>
    </div>
  ` : '';

  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${portfolio.userName} - VelsyMedia Developer Portfolio</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 40px;
            text-align: center;
        }

        .header h1 {
            font-size: 3em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        .header .subtitle {
            font-size: 1.3em;
            opacity: 0.9;
        }

        .header .completion-badge {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            padding: 10px 25px;
            border-radius: 25px;
            margin-top: 20px;
            font-size: 0.9em;
        }

        .content {
            padding: 40px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-bottom: 50px;
        }

        .stat-card {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .stat-card .icon {
            font-size: 3em;
            margin-bottom: 15px;
        }

        .stat-card .value {
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }

        .stat-card .label {
            color: #666;
            font-size: 1.1em;
        }

        .section {
            margin-bottom: 50px;
        }

        .section-title {
            font-size: 2em;
            margin-bottom: 30px;
            color: #667eea;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }

        .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }

        .skill-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }

        .skill-name {
            font-weight: 600;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
        }

        .skill-bar {
            background: #e9ecef;
            height: 8px;
            border-radius: 10px;
            overflow: hidden;
        }

        .skill-progress {
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            height: 100%;
            border-radius: 10px;
        }

        .achievement-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .achievement-card {
            background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .achievement-icon {
            font-size: 3em;
            margin-bottom: 10px;
        }

        .achievement-title {
            font-size: 1.3em;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .achievement-desc {
            color: #666;
            font-size: 0.95em;
        }

        .task-timeline {
            position: relative;
            padding-left: 40px;
        }

        .task-timeline::before {
            content: '';
            position: absolute;
            left: 15px;
            top: 0;
            bottom: 0;
            width: 3px;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }

        .task-item {
            position: relative;
            margin-bottom: 40px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }

        .task-item::before {
            content: '';
            position: absolute;
            left: -28px;
            top: 25px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: #667eea;
            border: 3px solid white;
        }

        .task-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .task-title {
            font-size: 1.3em;
            font-weight: bold;
            color: #333;
        }

        .task-score {
            font-size: 2em;
            font-weight: bold;
        }

        .score-excellent { color: #28a745; }
        .score-good { color: #ffc107; }
        .score-needs-improvement { color: #dc3545; }

        .task-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 15px 0;
            padding: 15px;
            background: white;
            border-radius: 8px;
        }

        .detail-item {
            text-align: center;
        }

        .detail-label {
            color: #666;
            font-size: 0.85em;
            margin-bottom: 5px;
        }

        .detail-value {
            font-weight: bold;
            color: #333;
        }

        .strengths {
            background: #d4edda;
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
        }

        .strengths-title {
            font-weight: bold;
            color: #155724;
            margin-bottom: 10px;
        }

        .strengths ul {
            list-style: none;
            padding-left: 0;
        }

        .strengths li::before {
            content: '✓ ';
            color: #28a745;
            font-weight: bold;
        }

        .tech-stack {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }

        .tech-badge {
            background: #667eea;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85em;
        }

        .footer {
            background: #2c3e50;
            color: white;
            padding: 40px;
            text-align: center;
        }

        .footer-links {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .footer-link {
            color: #3498db;
            text-decoration: none;
            font-size: 1.1em;
        }

        @media (max-width: 768px) {
            .header h1 { font-size: 2em; }
            .stats-grid { grid-template-columns: 1fr; }
            .content { padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>${portfolio.userName}</h1>
            <div class="subtitle">Junior Software Developer</div>
            <div class="subtitle">VelsyMedia Simulation Graduate</div>
            <div class="completion-badge">
                ✓ Completed on ${completionDate}
            </div>
        </div>

        <div class="content">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="icon">🏆</div>
                    <div class="value">${overallScore}%</div>
                    <div class="label">Overall Score</div>
                </div>
                <div class="stat-card">
                    <div class="icon">✅</div>
                    <div class="value">${portfolio.totalTasksCompleted}</div>
                    <div class="label">Tasks Completed</div>
                </div>
                <div class="stat-card">
                    <div class="icon">⏱️</div>
                    <div class="value">${formatTimeHTML(portfolio.totalTimeSpent)}</div>
                    <div class="label">Time Invested</div>
                </div>
                <div class="stat-card">
                    <div class="icon">🎖️</div>
                    <div class="value">${portfolio.achievements.length}</div>
                    <div class="label">Achievements</div>
                </div>
            </div>

            <div class="section">
                <h2 class="section-title">💻 Technical Skills Mastered</h2>
                <div class="skills-grid">
                    ${skillsHTML}
                </div>
            </div>

            <div class="section">
                <h2 class="section-title">🤝 Professional Skills Developed</h2>
                <div class="skills-grid">
                    ${softSkillsHTML}
                </div>
            </div>

            ${achievementsHTML}

            <div class="section">
                <h2 class="section-title">📊 Project Journey & Performance</h2>
                <div class="task-timeline">
                    ${tasksHTML}
                </div>
            </div>

            ${projectLinksHTML}
        </div>

        <div class="footer">
            <h3 style="margin-bottom: 15px;">VelsyMedia Junior Developer Simulation</h3>
            <p>This portfolio represents successful completion of the VelsyMedia Software Development training program.</p>
            <div class="footer-links">
                <a href="mailto:${portfolio.userEmail}" class="footer-link">✉️ ${portfolio.userEmail}</a>
                ${portfolio.githubUsername ? `<a href="https://github.com/${portfolio.githubUsername}" class="footer-link" target="_blank">🔗 GitHub: ${portfolio.githubUsername}</a>` : ''}
            </div>
            <p style="margin-top: 30px; opacity: 0.7; font-size: 0.9em;">
                Generated on ${new Date().toLocaleDateString()} | © ${new Date().getFullYear()} VelsyMedia
            </p>
        </div>
    </div>
</body>
</html>
  `;
}

function getScoreClass(score: number): string {
  if (score >= 80) return 'score-excellent';
  if (score >= 60) return 'score-good';
  return 'score-needs-improvement';
}

function formatTimeHTML(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m`;
  return `${seconds}s`;
}
