// GitHub file fetching service
export interface GitHubFileResult {
  error?: string;
  success: boolean;
  content?: string;
  // baseUrl removed - branch will be tried dynamically
  filename: string;
}

export interface GitHubRepoInfo {
  owner: string;
  repo: string;
  baseUrl: string;
}

export function parseGitHubUrl(url: string): GitHubRepoInfo | null {
  try {
    // Handle both formats:
    // https://github.com/username/reponame
    // https://github.com/username/reponame.git
    const cleanUrl = url.replace(/\.git$/, '');
    const match = cleanUrl.match(/github\.com\/([^\/]+)\/([^\/]+)/);
    if (!match) return null;
    
    const [, owner, repo] = match;
    return {
      owner,
      repo,
      baseUrl: `https://raw.githubusercontent.com/${owner}/${repo}`
    };
  } catch (error) {
    return null;
  }
}

export async function fetchGitHubFile(repoInfo: GitHubRepoInfo, filename: string): Promise<GitHubFileResult> {
  const branchesToTry = ['main', 'master', 'develop', 'gh-pages'];
  for (const branch of branchesToTry) {
    try {
      const fileUrl = `https://raw.githubusercontent.com/${repoInfo.owner}/${repoInfo.repo}/${branch}/${filename}`;
      const response = await fetch(fileUrl);

      if (!response.ok) {
        // try next branch on 404
        if (response.status === 404) continue;
        return {
          success: false,
          error: `Failed to fetch "${filename}" from branch ${branch}: ${response.status} ${response.statusText}`,
          filename
        };
      }

      const content = await response.text();
      return { success: true, content, filename };
    } catch (error) {
      // network error - return immediately
      return {
        success: false,
        error: `Network error while fetching "${filename}": ${error instanceof Error ? error.message : 'Unknown error'}`,
        filename
      };
    }
  }

  return {
    success: false,
    error: `File "${filename}" not found in any common branches (main/master/develop/gh-pages). Please verify the repository and file path.`,
    filename
  };
}

export async function fetchMultipleFiles(repoUrl: string, filenames: string[]): Promise<{
  repoInfo: GitHubRepoInfo | null;
  results: GitHubFileResult[];
}> {
  const repoInfo = parseGitHubUrl(repoUrl);
  
  if (!repoInfo) {
    return {
      repoInfo: null,
      results: filenames.map(filename => ({
        success: false,
        error: "Invalid GitHub URL format. Please use: https://github.com/username/reponame",
        filename
      }))
    };
  }
  
  const results = await Promise.all(
    filenames.map(filename => fetchGitHubFile(repoInfo, filename))
  );
  
  return { repoInfo, results };
}

// Save GitHub repo URL to localStorage for the current scene
export function saveRepoUrl(sceneId: string, repoUrl: string): void {
  localStorage.setItem(`github_repo_${sceneId}`, repoUrl);
}

// Get saved GitHub repo URL for the current scene
export function getSavedRepoUrl(sceneId: string): string | null {
  return localStorage.getItem(`github_repo_${sceneId}`);
}
