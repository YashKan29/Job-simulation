// Use Ollama with qwen3.5:cloud model
// Make sure Ollama service is running: ollama serve (in background/different terminal)
const OLLAMA_ENDPOINT = 'http://localhost:11434/api/generate';
// Use Vite env variable `VITE_OLLAMA_MODEL` in the browser; fallback to qwen3.5:cloud
const OLLAMA_MODEL = (import.meta.env.VITE_OLLAMA_MODEL as string) || 'qwen3.5:cloud';

// Simple Ollama request helper
export const getResponseForGivenPrompt = async (
  systemPrompt: string,
  userPrompt: string
): Promise<string> => {
  try {
    const fullPrompt = `${systemPrompt}\n\nUser: ${userPrompt}\n\nAssistant:`;

    const resp = await fetch(OLLAMA_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        prompt: fullPrompt,
        stream: false,
        temperature: 0.2
      })
    });

    if (!resp.ok) {
      const body = await resp.text().catch(() => '');
      if (resp.status === 404) {
        throw new Error(`Model '${OLLAMA_MODEL}' not found in Ollama. Available models: qwen:7b, qwen:4b, mistral, neural-chat, llama2. Run 'ollama pull qwen:7b' to install.`);
      }
      throw new Error(`Ollama API error ${resp.status}: ${body}`);
    }

    const data = await resp.json();

    // Ollama returns response in 'response' field
    if (data.response && typeof data.response === 'string') {
      return data.response;
    }

    return JSON.stringify(data);
  } catch (error) {
    console.error('Error getting Ollama response:', error);
    throw new Error("Sorry, couldn't connect to Ollama. Make sure Ollama is running on http://localhost:11434 with qwen3.5:397b model loaded.");
  }
};

/**
 * Checks if the user's program logic is correct compared to the expected logic/behavior.
 * Returns an object with result ('correct' | 'wrong') and a team leader style review.
 * @param userCode - The code/program provided by the user
 * @param expectedLogic - The expected logic, code, or behavior
 * @returns Promise<{ result: 'correct' | 'wrong', review: string }>
 */
export async function isAnswerCorrect(userCode: string, expectedLogic: string): Promise<{ result: 'correct' | 'wrong', review: string }> {
  if (!userCode || !expectedLogic) {
    return {
      result: 'wrong',
      review: 'No code or expected logic provided. Please submit your solution for review.'
    };
  }
  // Simplified prompt for AI evaluation
  const systemPrompt = `Evaluate if the user's code meets the expected requirements. Reply ONLY in this JSON format:\n{\n  "result": "correct" or "wrong",\n  "review": "<brief feedback>"\n}`;
  const userPrompt = `User's code:\n${userCode}\n\nExpected logic/behavior:\n${expectedLogic}`;
  const response = await getResponseForGivenPrompt(systemPrompt, userPrompt);
  let cleanedResponse = response.trim();
  // Remove markdown code block wrappers if present
  if (cleanedResponse.startsWith('```json')) {
    cleanedResponse = cleanedResponse.replace(/^```json\s*/, '');
  }
  if (cleanedResponse.startsWith('```')) {
    cleanedResponse = cleanedResponse.replace(/^```\s*/, '');
  }
  if (cleanedResponse.endsWith('```')) {
    cleanedResponse = cleanedResponse.replace(/\s*```$/, '');
  }
  try {
    const parsed = JSON.parse(cleanedResponse);
    if (parsed.result === 'correct' || parsed.result === 'wrong') {
      return parsed;
    }
  } catch (e) {
    // fallback if AI response is not JSON
  }
  return {
    result: 'wrong',
    review: 'Unable to determine correctness. Please review your code and ensure it meets the requirements.'
  };
}
