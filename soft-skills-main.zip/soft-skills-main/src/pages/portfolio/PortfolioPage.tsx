import { useAnalyticsStore } from '../../global/store/analyticsStore';
import { useState, useEffect } from 'react';
import { Download, Github, Mail, Award, TrendingUp, Clock, Code } from 'lucide-react';

export default function PortfolioPage() {
  const { portfolio, generatePortfolio } = useAnalyticsStore();
  const [portfolioHTML, setPortfolioHTML] = useState('');

  useEffect(() => {
    if (portfolio) {
      generatePortfolio().then(setPortfolioHTML);
    }
  }, [portfolio]);

  if (!portfolio) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">No Portfolio Data Found</h1>
          <p className="text-gray-600">Complete some tasks to generate your portfolio!</p>
        </div>
      </div>
    );
  }

  const handleDownload = () => {
    const blob = new Blob([portfolioHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${portfolio.userName.replace(/\s+/g, '_')}_VelsyMedia_Portfolio.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadJSON = () => {
    const blob = new Blob([JSON.stringify(portfolio, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${portfolio.userName.replace(/\s+/g, '_')}_analytics.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Your Professional Portfolio</h1>
              <p className="text-gray-600 mt-2">VelsyMedia Junior Developer Simulation</p>
            </div>
            <div className="flex gap-3 flex-wrap">
              <button
                onClick={handleDownloadJSON}
                className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                Download Analytics (JSON)
              </button>
              <button
                onClick={handleDownload}
                className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Download className="w-5 h-5" />
                Download Portfolio (HTML)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Portfolio Preview */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          {/* Personal Info */}
          <div className="border-b pb-6 mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">{portfolio.userName}</h2>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                {portfolio.userEmail}
              </div>
              {portfolio.githubUsername && (
                <div className="flex items-center gap-2">
                  <Github className="w-4 h-4" />
                  {portfolio.githubUsername}
                </div>
              )}
            </div>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <StatCard
              icon={<Award className="w-6 h-6 text-blue-600" />}
              title="Overall Score"
              value={`${portfolio.overallScore}%`}
              subtitle="Excellent performance"
            />
            <StatCard
              icon={<Code className="w-6 h-6 text-green-600" />}
              title="Tasks Completed"
              value={portfolio.totalTasksCompleted.toString()}
              subtitle="Out of 8 total"
            />
            <StatCard
              icon={<Clock className="w-6 h-6 text-purple-600" />}
              title="Time Invested"
              value={formatTime(portfolio.totalTimeSpent)}
              subtitle="Learning hours"
            />
            <StatCard
              icon={<TrendingUp className="w-6 h-6 text-orange-600" />}
              title="Achievements"
              value={portfolio.achievements.length.toString()}
              subtitle="Badges earned"
            />
          </div>

          {/* Skills Breakdown */}
          <div className="mb-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Technical Skills Acquired</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {Object.entries(portfolio.skillsAcquired.technical).map(([skill, level]: [string, unknown]) => (
                <SkillBar key={skill} skill={skill} level={level as number} />
              ))}
            </div>
          </div>

          {/* Soft Skills */}
          <div className="mb-8">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Soft Skills Developed</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {Object.entries(portfolio.skillsAcquired.soft).map(([skill, level]: [string, unknown]) => (
                <SkillBar key={skill} skill={skill} level={level as number} />
              ))}
            </div>
          </div>

          {/* Achievements */}
          {portfolio.achievements.length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Achievements Unlocked</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {portfolio.achievements.map((achievement: any) => (
                  <div
                    key={achievement.id}
                    className="bg-gradient-to-br from-yellow-50 to-orange-50 border-2 border-yellow-200 rounded-lg p-4"
                  >
                    <div className="text-4xl mb-2">{achievement.icon}</div>
                    <h4 className="font-bold text-gray-900">{achievement.title}</h4>
                    <p className="text-sm text-gray-600 mt-1">{achievement.description}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      {new Date(achievement.earnedAt).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Task Performance */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-4">Task Performance Breakdown</h3>
            <div className="space-y-4">
              {portfolio.taskAnalytics.map((task: any, index: number) => (
                <TaskCard key={index} task={task} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper Components
function StatCard({ icon, title, value, subtitle }: any) {
  return (
    <div className="bg-gradient-to-br from-gray-50 to-white border rounded-lg p-6">
      <div className="flex items-center gap-3 mb-3">
        {icon}
        <span className="text-sm font-medium text-gray-600">{title}</span>
      </div>
      <div className="text-3xl font-bold text-gray-900">{value}</div>
      <div className="text-xs text-gray-500 mt-1">{subtitle}</div>
    </div>
  );
}

function SkillBar({ skill, level }: { skill: string; level: number }) {
  return (
    <div>
      <div className="flex justify-between text-sm mb-1">
        <span className="font-medium text-gray-700">{skill}</span>
        <span className="text-gray-500">{level}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className="bg-blue-600 h-2 rounded-full transition-all duration-500"
          style={{ width: `${level}%` }}
        />
      </div>
    </div>
  );
}

function TaskCard({ task }: { task: any }) {
  return (
    <div className="border rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h4 className="font-bold text-gray-900">{task.sceneName}</h4>
          <p className="text-sm text-gray-600">{task.taskName}</p>
        </div>
        <div className="text-right">
          <div className={`text-2xl font-bold ${task.score >= 80 ? 'text-green-600' : task.score >= 60 ? 'text-yellow-600' : 'text-red-600'}`}>
            {task.score}%
          </div>
          <div className="text-xs text-gray-500">{task.attempts} attempt(s)</div>
        </div>
      </div>

      {task.strengths.length > 0 && (
        <div className="mb-3">
          <p className="text-sm font-medium text-green-700 mb-1">✓ Strengths:</p>
          <ul className="text-sm text-gray-600 list-disc list-inside">
            {task.strengths.slice(0, 2).map((strength: string, i: number) => (
              <li key={i}>{strength}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex flex-wrap gap-2 mt-3">
        {task.technicalSkills.map((skill: string) => (
          <span key={skill} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
            {skill}
          </span>
        ))}
      </div>
    </div>
  );
}

function formatTime(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}
