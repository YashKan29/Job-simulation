import { usePageNavigation } from "./global/hooks/navigation";
import routes from "./routes";

function App() {
  const { currentPage } = usePageNavigation();

  const pageComponent = routes[currentPage] || <div>Page not found</div>;
  
  console.log('Current page:', currentPage);
  console.log('Page component:', pageComponent);

  return <div style={{ minHeight: '100vh', backgroundColor: '#f5f5f5' }}>{pageComponent}</div>;
}

export default App;